# Contributing

Contributions should change traces, relations, evidence sources, forecast contracts, or settlement rules through reviewable pull requests. New concepts are not accepted as evidence by name alone. Every material forecast change must preserve the previous snapshot and provide a reason, evidence lineage, and expected effect on calibration.
