# Security

This repository is an offline research prototype. Do not connect forecast outputs directly to autonomous trading, procurement, safety-critical, medical, legal, employment, or public-benefit decisions. Report vulnerabilities through a private maintainer channel before public disclosure.
