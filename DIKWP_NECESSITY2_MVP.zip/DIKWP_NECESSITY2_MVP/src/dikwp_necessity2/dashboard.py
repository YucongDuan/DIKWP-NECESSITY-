from __future__ import annotations

import html
import json
from pathlib import Path


def build_dashboard(forecasts, simulation, horizon, output_path):
    rows=[]
    for f in sorted(forecasts, key=lambda x: (-x.probability, x.event_id)):
        pct=f.probability*100
        rows.append(f"<tr><td>{html.escape(f.event_id)}</td><td>{html.escape(f.title)}</td><td>{html.escape(f.event_type)}</td><td><div class='bar'><span style='width:{pct:.1f}%'></span></div>{pct:.1f}%</td><td>{html.escape(f.necessity_state)}</td><td>{html.escape(f.settlement_date)}</td></tr>")
    scenarios=''.join(f"<li><strong>{html.escape(k)}</strong>：{v*100:.1f}%</li>" for k,v in sorted(simulation['scenario_shares'].items(), key=lambda kv:-kv[1]))
    top=sorted(forecasts,key=lambda x:-x.probability)[:12]
    cards=''.join(f"<article><div class='p'>{f.probability*100:.1f}%</div><h3>{html.escape(f.title)}</h3><p>{html.escape(f.necessity_state)} · {html.escape(f.settlement_date)}</p></article>" for f in top)
    doc=f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DIKWP-NECESSITY²</title>
<style>body{{font-family:system-ui,-apple-system,"Noto Sans CJK SC",sans-serif;margin:0;background:#f5f7fa;color:#172033}}header{{padding:42px 6vw;background:#172033;color:white}}main{{max-width:1320px;margin:auto;padding:28px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px}}article,section{{background:white;border:1px solid #dfe5ec;border-radius:12px;padding:18px;margin-bottom:18px;box-shadow:0 2px 8px #0000000b}}article .p{{font-size:34px;font-weight:750}}table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{padding:10px;border-bottom:1px solid #e7ebf0;text-align:left;vertical-align:top}}.bar{{height:8px;background:#edf1f5;border-radius:8px;overflow:hidden;width:140px;display:inline-block;margin-right:8px}}.bar span{{display:block;height:100%;background:linear-gradient(90deg,#4f7cac,#76a5d4)}}code{{background:#eef2f6;padding:2px 5px;border-radius:4px}}small{{color:#667085}}@media(max-width:760px){{table{{font-size:12px}}.bar{{width:70px}}}}</style></head><body>
<header><h1>DIKWP-NECESSITY²</h1><p>无定义结构必然性、偶然触发与十二个月前沿AI精密预测系统</p><p>冻结快照：2026-07-18 · 结算上限：2027-07-18</p></header><main>
<section><h2>最强预测</h2><div class="grid">{cards}</div></section>
<section><h2>任务时域模型</h2><p>以2026年2月约12小时为合成起点，至2027年7月18日的投影：</p><ul><li>保守（210天翻倍）：{horizon['conservative_210d']:.1f}小时</li><li>中央（180天翻倍）：{horizon['central_180d']:.1f}小时</li><li>快速（131天翻倍）：{horizon['rapid_131d']:.1f}小时</li></ul><small>这是结构模型情景，不是已观测结果。</small></section>
<section><h2>20,000次结构压力测试</h2><ul>{scenarios}</ul><p>触发里程碑数量：P10={simulation['milestone_count']['p10']}，中位数={simulation['milestone_count']['median']}，P90={simulation['milestone_count']['p90']}。</p></section>
<section><h2>全部预测合同</h2><table><thead><tr><th>ID</th><th>事件</th><th>类型</th><th>概率</th><th>状态</th><th>结算日</th></tr></thead><tbody>{''.join(rows)}</tbody></table></section>
<section><h2>解释边界</h2><p>系统确定的是输入快照、变换关系、概率编译、失效条件与结算规则；它不声称偶然历史事件本身被物理决定。具体名称与日期属于表面层，结构功能与竞争走廊属于更高可预测层。</p></section>
</main></body></html>"""
    Path(output_path).write_text(doc,encoding='utf-8')
