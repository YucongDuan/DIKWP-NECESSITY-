from __future__ import annotations

import math


def change_point_z(history: list[float], latest: float) -> float:
    if len(history) < 4:
        return 0.0
    mean = sum(history) / len(history)
    var = sum((x-mean)**2 for x in history) / max(1, len(history)-1)
    sd = math.sqrt(var)
    if sd == 0:
        return float("inf") if latest != mean else 0.0
    return (latest-mean)/sd


def unknown_axis_candidate(traces: list[dict], threshold: float = 0.65) -> dict:
    """Find repeated residual relations without naming a concept."""
    residuals = {}
    for t in traces:
        if float(t.get("residual",0)) >= threshold:
            key = (t.get("source"), t.get("relation"), t.get("target"))
            residuals[key] = residuals.get(key,0)+1
    ranked=sorted(residuals.items(), key=lambda kv:(-kv[1], str(kv[0])))
    if not ranked:
        return {"candidate":None,"support":0}
    key,count=ranked[0]
    return {"candidate":"UAX-0001","support":count,"relation_signature":key,"name":None}
