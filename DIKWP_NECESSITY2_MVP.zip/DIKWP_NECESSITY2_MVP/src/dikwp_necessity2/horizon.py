from __future__ import annotations

import math
from datetime import date


def project_hours(start_hours: float, start_date: date, end_date: date, doubling_days: float) -> float:
    days = (end_date - start_date).days
    if days < 0 or start_hours <= 0 or doubling_days <= 0:
        raise ValueError("invalid horizon projection")
    return start_hours * (2 ** (days / doubling_days))


def projection_band(start_hours: float = 12.0, start_date: date = date(2026,2,1), end_date: date = date(2027,7,18)) -> dict[str,float]:
    # Conservative/central/accelerated trajectories. These are model assumptions, not observed facts.
    return {
        "conservative_210d": project_hours(start_hours, start_date, end_date, 210.0),
        "central_180d": project_hours(start_hours, start_date, end_date, 180.0),
        "rapid_131d": project_hours(start_hours, start_date, end_date, 131.0),
    }
