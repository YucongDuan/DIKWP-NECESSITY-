from __future__ import annotations

import math


def brier_score(probability: float, outcome: int) -> float:
    if not 0 <= probability <= 1 or outcome not in (0,1):
        raise ValueError("invalid input")
    return (probability - outcome) ** 2


def log_score(probability: float, outcome: int) -> float:
    if not 0 <= probability <= 1 or outcome not in (0,1):
        raise ValueError("invalid input")
    p = min(max(probability, 1e-15), 1 - 1e-15)
    return -math.log(p if outcome else 1-p)


def calibration_bins(records: list[tuple[float,int]], bins: int = 10) -> list[dict]:
    result=[]
    for i in range(bins):
        lo, hi = i/bins, (i+1)/bins
        group=[(p,y) for p,y in records if lo <= p < hi or (i==bins-1 and p==1)]
        if group:
            result.append({"lo":lo,"hi":hi,"count":len(group),"mean_probability":sum(p for p,_ in group)/len(group),"outcome_rate":sum(y for _,y in group)/len(group)})
    return result
