from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any

TYPES = ("D", "I", "K", "W", "P")

DESCRIPTIONS = {
    "D": "可追溯观测、事件、参数与原始记录",
    "I": "差异、关系、模式、时间顺序与上下文",
    "K": "可检验模型、因果主张、反事实与复现",
    "W": "长期后果、价值冲突、福利、风险与不可逆性",
    "P": "目的、权限、拒绝、资源分配与行动方向",
}

@dataclass(frozen=True)
class Transform:
    source: str
    target: str
    operator_id: str
    description: str


def all_transforms() -> list[Transform]:
    result = []
    for source in TYPES:
        for target in TYPES:
            result.append(Transform(
                source=source,
                target=target,
                operator_id=f"T-{source}{target}",
                description=f"在明确观察者、语境、时间、尺度和意图场下，将{DESCRIPTIONS[source]}作为资源转化或修订{DESCRIPTIONS[target]}。"
            ))
    return result


def mixed_type(vector: dict[str, float]) -> dict[str, float]:
    clean = {k: max(0.0, float(vector.get(k, 0.0))) for k in TYPES}
    total = sum(clean.values())
    if total <= 0:
        return {k: 0.2 for k in TYPES}
    return {k: v / total for k, v in clean.items()}


def relation_fingerprint(bundle: dict[str, Any], erase_concepts: bool = False) -> str:
    """Hash relation structure. Concept labels can be erased without changing relation topology."""
    traces = []
    for item in bundle.get("traces", []):
        traces.append({
            "id": item.get("id"),
            "source": item.get("source"),
            "target": item.get("target"),
            "relation": item.get("relation"),
            "dikwp": mixed_type(item.get("dikwp", {})),
            "concept": None if erase_concepts else item.get("concept"),
        })
    # In the definition-free audit, labels are excluded in both fingerprints.
    if erase_concepts:
        for t in traces:
            t.pop("concept", None)
    payload = json.dumps(sorted(traces, key=lambda x: str(x.get("id"))), ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def concept_erasure_invariant(bundle: dict[str, Any]) -> bool:
    no_labels = {"traces": []}
    for item in bundle.get("traces", []):
        clone = dict(item)
        clone.pop("concept", None)
        no_labels["traces"].append(clone)
    return relation_fingerprint(bundle, erase_concepts=True) == relation_fingerprint(no_labels, erase_concepts=True)
