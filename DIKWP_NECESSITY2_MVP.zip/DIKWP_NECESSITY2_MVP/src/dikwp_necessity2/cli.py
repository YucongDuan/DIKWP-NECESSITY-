from __future__ import annotations

import argparse
import csv
import hashlib
import json
from dataclasses import asdict
from datetime import date
from pathlib import Path

from .dashboard import build_dashboard
from .engine import compile_contracts
from .horizon import projection_band
from .mesh import all_transforms
from .simulation import simulate


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''):
            h.update(chunk)
    return h.hexdigest()


def main(argv=None):
    parser=argparse.ArgumentParser(description='DIKWP-NECESSITY² forecast compiler')
    parser.add_argument('--config',default='config/forecast_contracts.json')
    parser.add_argument('--out',default='outputs')
    parser.add_argument('--trials',type=int,default=20000)
    parser.add_argument('--seed',type=int,default=7182026)
    args=parser.parse_args(argv)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    forecasts=compile_contracts(args.config)
    sim=simulate(forecasts,args.trials,args.seed)
    horizon=projection_band()
    (out/'forecast_contracts_compiled.json').write_text(json.dumps([asdict(f) for f in forecasts],ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'forecast_contracts.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(['id','title','type','probability','state','settlement_date','peak_month','criterion'])
        for x in forecasts:w.writerow([x.event_id,x.title,x.event_type,f'{x.probability:.6f}',x.necessity_state,x.settlement_date,x.peak_month,x.resolution_criterion])
    (out/'simulation_summary.json').write_text(json.dumps(sim,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'task_horizon_projection.json').write_text(json.dumps(horizon,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'dikwp_25_transforms.json').write_text(json.dumps([asdict(t) for t in all_transforms()],ensure_ascii=False,indent=2),encoding='utf-8')
    build_dashboard(forecasts,sim,horizon,out/'dashboard.html')
    proof={
        'system':'DIKWP-NECESSITY²','run_at':date.today().isoformat(),'snapshot_date':'2026-07-18',
        'trials':args.trials,'seed':args.seed,'forecast_count':len(forecasts),'transform_count':len(all_transforms()),
        'files':{}
    }
    for path in sorted(out.iterdir()):
        if path.is_file() and path.name!='RUN_PROOF.json':proof['files'][path.name]=sha256(path)
    (out/'RUN_PROOF.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'forecast_count':len(forecasts),'trials':args.trials,'dashboard':str(out/'dashboard.html')},ensure_ascii=False))

if __name__=='__main__':main()
