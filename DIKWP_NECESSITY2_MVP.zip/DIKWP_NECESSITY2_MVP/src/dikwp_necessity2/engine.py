from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

FEATURES = (
    "structural_pressure", "technical_feasibility", "actor_intent",
    "trigger_observability", "route_redundancy", "blocker_load", "surface_specificity"
)

@dataclass(frozen=True)
class CompiledForecast:
    event_id: str
    title: str
    event_type: str
    probability: float
    necessity_state: str
    settlement_date: str
    resolution_criterion: str
    features: dict[str, float]
    source_ids: list[str]
    peak_month: str


def sigmoid(x: float) -> float:
    if x >= 0:
        z = math.exp(-x)
        return 1.0 / (1.0 + z)
    z = math.exp(x)
    return z / (1.0 + z)


def compile_probability(features: dict[str, float], formula: dict[str, Any]) -> float:
    z = float(formula["intercept"])
    for name, weight in formula["weights"].items():
        value = float(features[name])
        if not 0.0 <= value <= 1.0:
            raise ValueError(f"feature {name} outside [0,1]")
        z += float(weight) * value
    return sigmoid(z)


def state_for(probability: float, event_type: str, surface_specificity: float) -> str:
    # Operational forecast states, not ontology or concept definitions.
    if event_type == "NO_EVENT" and probability >= 0.97:
        return "N3-否定结构必然"
    if probability >= 0.97 and surface_specificity <= 0.15:
        return "N3-结构必然"
    if probability >= 0.90:
        return "N2-强条件必然"
    if probability >= 0.75:
        return "N1-高概率走廊"
    if probability >= 0.40:
        return "B-竞争分支"
    return "X-低频冲击"


def compile_contracts(config_path: str | Path) -> list[CompiledForecast]:
    cfg = json.loads(Path(config_path).read_text(encoding="utf-8"))
    out = []
    for event in cfg["events"]:
        p = compile_probability(event["features"], cfg["formula"])
        out.append(CompiledForecast(
            event_id=event["id"], title=event["title"], event_type=event["type"],
            probability=p,
            necessity_state=state_for(p, event["type"], event["features"]["surface_specificity"]),
            settlement_date=event["settlement_date"],
            resolution_criterion=event["resolution_criterion"],
            features=event["features"], source_ids=event["source_ids"], peak_month=event["peak_month"]
        ))
    return out


def update_probability(prior: float, likelihood_ratios: list[tuple[float, float]]) -> float:
    """Bayesian odds update. Each tuple is (likelihood_ratio, source_independence 0..1)."""
    prior = min(max(prior, 1e-9), 1 - 1e-9)
    log_odds = math.log(prior / (1 - prior))
    for lr, independence in likelihood_ratios:
        if lr <= 0 or not 0 <= independence <= 1:
            raise ValueError("invalid evidence update")
        log_odds += independence * math.log(lr)
    return sigmoid(log_odds)
