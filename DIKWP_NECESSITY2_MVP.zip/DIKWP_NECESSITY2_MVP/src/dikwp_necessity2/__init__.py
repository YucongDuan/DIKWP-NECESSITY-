"""DIKWP-NECESSITY²: deterministic forecast compiler for uncertain futures."""

__version__ = '0.1.0'

