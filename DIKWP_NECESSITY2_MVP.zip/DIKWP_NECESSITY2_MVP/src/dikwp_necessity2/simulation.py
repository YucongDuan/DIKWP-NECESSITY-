from __future__ import annotations

import math
import random
from collections import Counter
from dataclasses import asdict
from typing import Iterable

from .engine import CompiledForecast, sigmoid

FACTOR_LOADINGS = {
    "STRUCTURAL": (0.60, 0.10, 0.05, 0.15, 0.10),
    "CAPABILITY": (0.65, 0.15, 0.00, 0.10, 0.10),
    "WINDOW": (0.35, 0.20, 0.20, 0.15, 0.10),
    "SHOCK": (0.15, 0.15, 0.45, 0.15, 0.10),
    "NO_EVENT": (-0.15, 0.05, -0.15, 0.05, 0.05),
}


def logit(p: float) -> float:
    p = min(max(p, 1e-9), 1 - 1e-9)
    return math.log(p / (1 - p))


def simulate(forecasts: Iterable[CompiledForecast], trials: int = 20000, seed: int = 7182026) -> dict:
    rng = random.Random(seed)
    forecasts = list(forecasts)
    counts = Counter()
    event_hits = Counter()
    milestone_counts = []
    for _ in range(trials):
        # capability, regulation, incident pressure, open-weight pressure, compute supply
        latent = [rng.gauss(0, 1) for _ in range(5)]
        hit_count = 0
        shock_count = 0
        structural_count = 0
        for f in forecasts:
            load = FACTOR_LOADINGS.get(f.event_type, FACTOR_LOADINGS["WINDOW"])
            adjustment = sum(a*b for a,b in zip(load, latent)) * 0.33
            p = sigmoid(logit(f.probability) + adjustment)
            hit = rng.random() < p
            if hit:
                event_hits[f.event_id] += 1
                hit_count += 1
                if f.event_type == "SHOCK": shock_count += 1
                if f.event_type == "STRUCTURAL": structural_count += 1
        milestone_counts.append(hit_count)
        # Scenario labels describe the dominant latent historical corridor, not whether
        # individual forecast events occur. This prevents several high-base-rate shock
        # contracts from forcing nearly every trial into the shock scenario.
        if latent[2] > 0.90:
            counts["安全/政策冲击走廊"] += 1
        elif latent[0] > 0.80 and latent[4] > 0.00:
            counts["加速智能体跃迁走廊"] += 1
        elif latent[4] < -0.90:
            counts["算力与部署瓶颈走廊"] += 1
        else:
            counts["智能体化基准走廊"] += 1
    milestone_counts.sort()
    def q(frac: float) -> int:
        return milestone_counts[min(trials-1, max(0, int(frac*(trials-1))))]
    return {
        "trials": trials, "seed": seed,
        "scenario_shares": {k: v/trials for k,v in counts.items()},
        "event_frequencies": {k: v/trials for k,v in event_hits.items()},
        "milestone_count": {"p10":q(.1),"median":q(.5),"p90":q(.9)},
    }
