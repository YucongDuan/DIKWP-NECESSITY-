from datetime import date
import json
from pathlib import Path

from dikwp_necessity2.engine import compile_contracts, compile_probability, update_probability
from dikwp_necessity2.horizon import project_hours, projection_band
from dikwp_necessity2.mesh import all_transforms, concept_erasure_invariant, mixed_type
from dikwp_necessity2.novelty import change_point_z, unknown_axis_candidate
from dikwp_necessity2.settlement import brier_score, log_score
from dikwp_necessity2.simulation import simulate

ROOT=Path(__file__).resolve().parents[1]

def test_all_25_transforms():
    transforms=all_transforms()
    assert len(transforms)==25
    assert len({(t.source,t.target) for t in transforms})==25

def test_probability_deterministic():
    cfg=json.loads((ROOT/'config/forecast_contracts.json').read_text(encoding='utf-8'))
    e=cfg['events'][0]
    assert compile_probability(e['features'],cfg['formula'])==compile_probability(e['features'],cfg['formula'])

def test_probability_bounds():
    cfg=json.loads((ROOT/'config/forecast_contracts.json').read_text(encoding='utf-8'))
    for e in cfg['events']:
        p=compile_probability(e['features'],cfg['formula'])
        assert 0 < p < 1

def test_concept_erasure():
    bundle=json.loads((ROOT/'examples/definition_free_trace_bundle.json').read_text(encoding='utf-8'))
    assert concept_erasure_invariant(bundle)

def test_mixed_type_normalizes():
    x=mixed_type({'D':2,'I':1})
    assert abs(sum(x.values())-1)<1e-12

def test_contract_predicates_nonempty():
    forecasts=compile_contracts(ROOT/'config/forecast_contracts.json')
    assert len(forecasts)>=35
    assert all(f.resolution_criterion.strip() for f in forecasts)

def test_surface_specificity_penalty():
    cfg=json.loads((ROOT/'config/forecast_contracts.json').read_text(encoding='utf-8'))
    base={k:.8 for k in cfg['formula']['weights']}
    base['blocker_load']=.1;base['surface_specificity']=.1
    p1=compile_probability(base,cfg['formula'])
    base['surface_specificity']=.9
    p2=compile_probability(base,cfg['formula'])
    assert p1>p2

def test_horizon_monotonic():
    a=project_hours(12,date(2026,2,1),date(2026,8,1),180)
    b=project_hours(12,date(2026,2,1),date(2027,7,18),180)
    assert b>a>12

def test_brier_and_log():
    assert brier_score(.9,1)<brier_score(.6,1)
    assert log_score(.9,1)<log_score(.6,1)

def test_bayesian_update():
    assert update_probability(.5,[(2.0,1.0)])>.5
    assert update_probability(.5,[(.5,1.0)])<.5

def test_novelty():
    traces=[{'source':'a','relation':'r','target':'b','residual':.8},{'source':'a','relation':'r','target':'b','residual':.9}]
    x=unknown_axis_candidate(traces)
    assert x['candidate']=='UAX-0001' and x['name'] is None

def test_change_point():
    assert change_point_z([1,1,1,1],2)==float('inf')

def test_simulation_reproducible():
    f=compile_contracts(ROOT/'config/forecast_contracts.json')
    a=simulate(f,200,7);b=simulate(f,200,7)
    assert a==b
