# Governance

No author has permanent authority over a forecast. Contract wording is frozen after its freeze date. Settlements require source citations and an independent reviewer. Failed forecasts remain public. Forks may compete through better calibration.
